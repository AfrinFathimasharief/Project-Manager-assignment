package main

import (
    "fmt"
    "net/http"
    "time"
)

func handler(w http.ResponseWriter, r *http.Request) {
    currentTime := time.Now().Format("Monday, 02-Jan-2006 15:04:05 MST")
    message := fmt.Sprintf("🕒 Current Date & Time: %s\n", currentTime)
    fmt.Fprintln(w, message)
}

func main() {
    http.HandleFunc("/", handler)
    fmt.Println("✅ Server is running on port 8080")
    http.ListenAndServe(":8080", nil)
}